import React from "react";

let Navbar = () =>{
    return(
        <React.Fragment>
             <nav className="navbar navbar-dark bg-dark navbar-expand-sm">
                <div className="container">
                    <a href="/" className="navbar-brand">React with Singer Royalty Calculation</a>
                </div>
               
             </nav>
             
        </React.Fragment>
    )
}
export default Navbar;